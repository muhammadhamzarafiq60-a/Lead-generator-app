import React, { useState, useEffect, useMemo, useRef } from "react";
import {
  Search, Bell, ChevronDown, Sparkles, TrendingUp, Users, Building2, Mail, Phone,
  Linkedin, Filter, Download, Plus, X, Check, ArrowUpRight, LayoutDashboard,
  ListFilter, UserSearch, FolderKanban, BrainCircuit, Database, Megaphone,
  BarChart3, Plug, Settings, ChevronRight, MapPin, Clock, CircleDot,
  ShieldCheck, AlertTriangle, ArrowRight, Menu, Radar, Zap, CreditCard,
  HelpCircle, ChevronLeft, MoreHorizontal, ExternalLink, Globe2
} from "lucide-react";
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis,
  ResponsiveContainer, Tooltip, CartesianGrid
} from "recharts";

/* ------------------------------------------------------------------ */
/*  Design tokens                                                      */
/* ------------------------------------------------------------------ */
const C = {
  bg: "#F6F7F9",
  surface: "#FFFFFF",
  surfaceAlt: "#FBFBFC",
  ink: "#12161C",
  ink2: "#3A414D",
  muted: "#7B8493",
  faint: "#AEB4BF",
  border: "#E5E8ED",
  borderStrong: "#D7DBE2",
  primary: "#2B3A67",
  primaryDeep: "#1C2745",
  primarySoft: "#EEF1F8",
  accent: "#17B890",
  accentSoft: "#E4F8F1",
  accentDeep: "#0E8F6E",
  warn: "#F2994A",
  warnSoft: "#FCEEE0",
  danger: "#E0574B",
  dangerSoft: "#FBEAE8",
  gold: "#C9A24B",
};

const FONT_DISPLAY = "'Space Grotesk', 'Inter', sans-serif";
const FONT_BODY = "'Inter', -apple-system, sans-serif";
const FONT_MONO = "'IBM Plex Mono', ui-monospace, monospace";

const GlobalStyle = () => (
  <style>{`
    @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500;600&display=swap');
    * { box-sizing: border-box; }
    .lp-scope { font-family: ${FONT_BODY}; color: ${C.ink}; -webkit-font-smoothing: antialiased; }
    .lp-scope ::selection { background: ${C.accentSoft}; color: ${C.accentDeep}; }
    .lp-scrollbar::-webkit-scrollbar { width: 8px; height: 8px; }
    .lp-scrollbar::-webkit-scrollbar-thumb { background: ${C.borderStrong}; border-radius: 8px; }
    .lp-scrollbar::-webkit-scrollbar-track { background: transparent; }
    .lp-row { transition: background .12s ease; }
    .lp-row:hover { background: ${C.surfaceAlt}; }
    .lp-btn { transition: transform .12s ease, box-shadow .12s ease, background .12s ease, border-color .12s ease; cursor: pointer; }
    .lp-btn:active { transform: scale(0.97); }
    .lp-navitem { transition: background .15s ease, color .15s ease; cursor: pointer; }
    .lp-card { transition: box-shadow .2s ease, transform .2s ease; }
    .lp-fadeup { animation: lpFadeUp .5s ease both; }
    @keyframes lpFadeUp { from { opacity: 0; transform: translateY(8px);} to { opacity: 1; transform: translateY(0);} }
    .lp-fadein { animation: lpFadeIn .4s ease both; }
    @keyframes lpFadeIn { from { opacity: 0;} to { opacity: 1;} }
    @keyframes lpPulse { 0% { box-shadow: 0 0 0 0 rgba(23,184,144,0.45);} 70% { box-shadow: 0 0 0 7px rgba(23,184,144,0);} 100% { box-shadow: 0 0 0 0 rgba(23,184,144,0);} }
    .lp-signal { animation: lpPulse 2.2s infinite; }
    @keyframes lpSpin { to { transform: rotate(360deg); } }
    .lp-spin { animation: lpSpin 8s linear infinite; }
    @keyframes lpStagger { from { opacity:0; transform: translateY(6px);} to { opacity:1; transform: translateY(0);} }
    .lp-stagger-row { animation: lpStagger .35s ease both; }
    .lp-drawer-in { animation: lpDrawerIn .28s cubic-bezier(.2,.8,.2,1) both; }
    @keyframes lpDrawerIn { from { transform: translateX(24px); opacity:0;} to { transform: translateX(0); opacity:1;} }
    @keyframes lpOverlayIn { from { opacity:0;} to { opacity:1;} }
    .lp-overlay-in { animation: lpOverlayIn .2s ease both; }
    input:focus, button:focus, textarea:focus { outline: none; }
    .lp-focusable:focus-visible { outline: 2px solid ${C.primary}; outline-offset: 2px; }
    .lp-scope table { border-collapse: collapse; }
    @media (max-width: 860px) {
      .lp-hide-mobile { display: none !important; }
      .lp-table-wrap { overflow-x: auto; }
    }
  `}</style>
);

/* ------------------------------------------------------------------ */
/*  Mock data                                                          */
/* ------------------------------------------------------------------ */
const INDUSTRIES = ["SaaS", "Fintech", "E-commerce", "Healthtech", "Cybersecurity", "Manufacturing", "Marketing", "Logistics"];
const LOCATIONS = ["London, UK", "Austin, TX", "Berlin, DE", "Toronto, CA", "Sydney, AU", "New York, NY", "Amsterdam, NL", "San Francisco, CA"];

const COMPANIES = [
  { id: "c1", name: "Northwind Analytics", industry: "SaaS", employees: "120-250", revenue: "$12M-$25M", location: "London, UK", founded: 2018, funding: "Series B · $34M", tech: ["Salesforce", "AWS", "Segment"], growth: "+38% headcount YoY", hiring: true, score: 91 },
  { id: "c2", name: "Fintra Labs", industry: "Fintech", employees: "50-120", revenue: "$5M-$12M", location: "Berlin, DE", founded: 2020, funding: "Series A · $14M", tech: ["Stripe", "HubSpot", "GCP"], growth: "+21% headcount YoY", hiring: true, score: 84 },
  { id: "c3", name: "Cartway Commerce", industry: "E-commerce", employees: "250-500", revenue: "$25M-$60M", location: "Austin, TX", founded: 2016, funding: "Series C · $61M", tech: ["Shopify Plus", "Klaviyo"], growth: "+14% headcount YoY", hiring: false, score: 67 },
  { id: "c4", name: "Vireo Health Systems", industry: "Healthtech", employees: "120-250", revenue: "$12M-$25M", location: "Toronto, CA", founded: 2019, funding: "Series B · $28M", tech: ["Salesforce", "Twilio"], growth: "+29% headcount YoY", hiring: true, score: 88 },
  { id: "c5", name: "Cipher Perimeter", industry: "Cybersecurity", employees: "50-120", revenue: "$5M-$12M", location: "Amsterdam, NL", founded: 2021, funding: "Seed · $6M", tech: ["Okta", "Datadog"], growth: "+44% headcount YoY", hiring: true, score: 79 },
  { id: "c6", name: "Fabrik Industrial", industry: "Manufacturing", employees: "500-1000", revenue: "$60M-$150M", location: "Sydney, AU", founded: 2009, funding: "Private", tech: ["SAP", "Microsoft Dynamics"], growth: "+6% headcount YoY", hiring: false, score: 52 },
  { id: "c7", name: "Loopwave Media", industry: "Marketing", employees: "20-50", revenue: "$2M-$5M", location: "New York, NY", founded: 2022, funding: "Seed · $3.2M", tech: ["HubSpot", "Notion"], growth: "+51% headcount YoY", hiring: true, score: 73 },
  { id: "c8", name: "Portside Logistics", industry: "Logistics", employees: "250-500", revenue: "$25M-$60M", location: "San Francisco, CA", founded: 2015, funding: "Series B · $40M", tech: ["Salesforce", "Snowflake"], growth: "+18% headcount YoY", hiring: true, score: 81 },
];

const FIRST = ["Amelia", "Noah", "Priya", "Marcus", "Elena", "Jonas", "Kavi", "Sofia", "Daniel", "Freya", "Omar", "Ines", "Lucas", "Nadia", "Theo", "Grace", "Rafael", "Mei", "Isaac", "Clara"];
const LAST = ["Chen", "Whitfield", "Rao", "Boone", "Delgado", "Muller", "Nair", "Almeida", "Okafor", "Larsen", "Haddad", "Bergstrom", "Silva", "Kowalski", "Fraser", "Novak", "Dubois", "Tanaka", "Reyes", "Petrov"];
const TITLES = [
  { t: "VP of Sales", dept: "Sales", seniority: "VP" },
  { t: "Head of Growth", dept: "Marketing", seniority: "Head" },
  { t: "Chief Technology Officer", dept: "Engineering", seniority: "C-Level" },
  { t: "Director of Revenue Operations", dept: "Sales", seniority: "Director" },
  { t: "Chief Marketing Officer", dept: "Marketing", seniority: "C-Level" },
  { t: "VP of Product", dept: "Product", seniority: "VP" },
  { t: "Head of Partnerships", dept: "Business Development", seniority: "Head" },
  { t: "Director of Engineering", dept: "Engineering", seniority: "Director" },
];

function seededRand(seed) {
  let x = Math.sin(seed) * 10000;
  return x - Math.floor(x);
}

const PEOPLE = Array.from({ length: 24 }).map((_, i) => {
  const co = COMPANIES[i % COMPANIES.length];
  const first = FIRST[i % FIRST.length];
  const last = LAST[(i * 3 + 2) % LAST.length];
  const title = TITLES[(i * 5 + 1) % TITLES.length];
  const r = seededRand(i * 17.3);
  const score = Math.round(50 + r * 49);
  const intentPool = ["Hiring surge", "New tech adopted", "Website activity spike", "Recent funding", "Expansion signal"];
  const verifPool = ["Verified", "Found", "Needs Verification"];
  return {
    id: `p${i + 1}`,
    name: `${first} ${last}`,
    title: title.t,
    dept: title.dept,
    seniority: title.seniority,
    company: co.name,
    companyId: co.id,
    industry: co.industry,
    location: LOCATIONS[i % LOCATIONS.length],
    email: `${first.toLowerCase()}.${last.toLowerCase()}@${co.name.toLowerCase().replace(/[^a-z]/g, "").slice(0, 10)}.com`,
    phone: `+1 (${300 + (i % 6) * 11}) 555-${1000 + i * 37}`,
    linkedin: `linkedin.com/in/${first.toLowerCase()}${last.toLowerCase()}`,
    companySize: co.employees,
    score,
    intent: intentPool[i % intentPool.length],
    verification: verifPool[i % verifPool.length],
    lastUpdated: `${(i % 6) + 1}d ago`,
    icpFit: Math.round(60 + seededRand(i * 3.1) * 40),
    buyingIntent: Math.round(50 + seededRand(i * 5.7) * 50),
    companyFit: Math.round(55 + seededRand(i * 9.2) * 45),
    roleFit: Math.round(60 + seededRand(i * 11.4) * 40),
    dataQuality: Math.round(70 + seededRand(i * 13.6) * 30),
  };
});

const LEADS_OVER_TIME = [
  { d: "Wk 1", leads: 120 }, { d: "Wk 2", leads: 168 }, { d: "Wk 3", leads: 149 },
  { d: "Wk 4", leads: 210 }, { d: "Wk 5", leads: 264 }, { d: "Wk 6", leads: 241 },
  { d: "Wk 7", leads: 305 }, { d: "Wk 8", leads: 338 },
];

const INDUSTRY_BREAKDOWN = INDUSTRIES.map((name, i) => ({
  name, value: [312, 248, 190, 165, 140, 98, 121, 87][i],
}));

const QUALITY_DIST = [
  { name: "Excellent (80-100)", value: 218, color: C.accent },
  { name: "Good (60-79)", value: 341, color: C.primary },
  { name: "Fair (40-59)", value: 190, color: C.warn },
  { name: "Weak (<40)", value: 96, color: C.faint },
];

const LISTS = [
  { id: "l1", name: "UK SaaS Prospects", count: 84, updated: "2h ago" },
  { id: "l2", name: "Enterprise CTOs", count: 41, updated: "1d ago" },
  { id: "l3", name: "E-commerce Decision Makers", count: 62, updated: "3d ago" },
  { id: "l4", name: "High Intent Leads", count: 129, updated: "5h ago" },
  { id: "l5", name: "Agency Prospects", count: 27, updated: "6d ago" },
];

const NAV_ITEMS = [
  { id: "overview", label: "Overview", icon: LayoutDashboard },
  { id: "find", label: "Find Leads", icon: ListFilter },
  { id: "companies", label: "Companies", icon: Building2 },
  { id: "people", label: "People", icon: UserSearch },
  { id: "lists", label: "Lists", icon: FolderKanban },
  { id: "research", label: "AI Research", icon: BrainCircuit },
  { id: "enrichment", label: "Enrichment", icon: Database },
  { id: "campaigns", label: "Campaigns", icon: Megaphone },
  { id: "analytics", label: "Analytics", icon: BarChart3 },
  { id: "integrations", label: "Integrations", icon: Plug },
  { id: "settings", label: "Settings", icon: Settings },
];

/* ------------------------------------------------------------------ */
/*  Small shared bits                                                  */
/* ------------------------------------------------------------------ */
function CountUp({ value, duration = 900, format = (v) => Math.round(v).toLocaleString() }) {
  const [n, setN] = useState(0);
  const ref = useRef(null);
  useEffect(() => {
    let start = null;
    const step = (t) => {
      if (!start) start = t;
      const p = Math.min(1, (t - start) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      setN(value * eased);
      if (p < 1) ref.current = requestAnimationFrame(step);
    };
    ref.current = requestAnimationFrame(step);
    return () => cancelAnimationFrame(ref.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);
  return <span>{format(n)}</span>;
}

function ScoreRing({ score, size = 56, stroke = 5 }) {
  const [progress, setProgress] = useState(0);
  useEffect(() => {
    const t = setTimeout(() => setProgress(score), 120);
    return () => clearTimeout(t);
  }, [score]);
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const color = score >= 80 ? C.accent : score >= 60 ? C.primary : score >= 40 ? C.warn : C.faint;
  return (
    <div style={{ position: "relative", width: size, height: size }}>
      <svg width={size} height={size} style={{ transform: "rotate(-90deg)" }}>
        <circle cx={size / 2} cy={size / 2} r={r} stroke={C.border} strokeWidth={stroke} fill="none" />
        <circle
          cx={size / 2} cy={size / 2} r={r} stroke={color} strokeWidth={stroke} fill="none"
          strokeLinecap="round" strokeDasharray={c}
          strokeDashoffset={c - (progress / 100) * c}
          style={{ transition: "stroke-dashoffset 1s cubic-bezier(.2,.8,.2,1)" }}
        />
      </svg>
      <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: FONT_MONO, fontWeight: 600, fontSize: size * 0.28, color: C.ink }}>
        {score}
      </div>
    </div>
  );
}

function Badge({ children, tone = "neutral", icon: Icon, dot }) {
  const tones = {
    neutral: { bg: C.surfaceAlt, fg: C.ink2, bd: C.border },
    accent: { bg: C.accentSoft, fg: C.accentDeep, bd: "transparent" },
    primary: { bg: C.primarySoft, fg: C.primary, bd: "transparent" },
    warn: { bg: C.warnSoft, fg: "#9A5B1E", bd: "transparent" },
    danger: { bg: C.dangerSoft, fg: "#A83A2F", bd: "transparent" },
  };
  const s = tones[tone];
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 5, padding: "3px 9px",
      borderRadius: 999, background: s.bg, color: s.fg, border: `1px solid ${s.bd}`,
      fontSize: 12, fontWeight: 600, whiteSpace: "nowrap",
    }}>
      {dot && <span style={{ width: 6, height: 6, borderRadius: 999, background: s.fg }} className={tone === "accent" ? "lp-signal" : ""} />}
      {Icon && <Icon size={12} strokeWidth={2.5} />}
      {children}
    </span>
  );
}

function Btn({ children, variant = "primary", icon: Icon, onClick, size = "md", style }) {
  const sizes = { sm: { padding: "7px 12px", fontSize: 13 }, md: { padding: "9px 16px", fontSize: 14 } };
  const variants = {
    primary: { background: C.primary, color: "#fff", border: `1px solid ${C.primary}` },
    accent: { background: C.accent, color: "#fff", border: `1px solid ${C.accent}` },
    ghost: { background: "transparent", color: C.ink2, border: `1px solid ${C.border}` },
    subtle: { background: C.surfaceAlt, color: C.ink2, border: `1px solid ${C.border}` },
  };
  return (
    <button
      onClick={onClick}
      className="lp-btn lp-focusable"
      style={{
        display: "inline-flex", alignItems: "center", gap: 7, borderRadius: 9,
        fontWeight: 600, fontFamily: FONT_BODY, ...sizes[size], ...variants[variant], ...style,
      }}
      onMouseEnter={(e) => { if (variant === "primary") e.currentTarget.style.background = C.primaryDeep; if (variant === "accent") e.currentTarget.style.background = C.accentDeep; if (variant === "ghost" || variant === "subtle") e.currentTarget.style.borderColor = C.borderStrong; }}
      onMouseLeave={(e) => { if (variant === "primary") e.currentTarget.style.background = C.primary; if (variant === "accent") e.currentTarget.style.background = C.accent; if (variant === "ghost" || variant === "subtle") e.currentTarget.style.borderColor = C.border; }}
    >
      {Icon && <Icon size={15} strokeWidth={2.2} />}
      {children}
    </button>
  );
}

function Card({ children, style, className = "" }) {
  return (
    <div className={`lp-card ${className}`} style={{
      background: C.surface, border: `1px solid ${C.border}`, borderRadius: 14,
      ...style,
    }}>
      {children}
    </div>
  );
}

function SectionTitle({ eyebrow, title, action }) {
  return (
    <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", marginBottom: 16, flexWrap: "wrap", gap: 10 }}>
      <div>
        {eyebrow && <div style={{ fontSize: 12, fontWeight: 700, color: C.accentDeep, letterSpacing: 0.4, marginBottom: 4, textTransform: "uppercase" }}>{eyebrow}</div>}
        <div style={{ fontFamily: FONT_DISPLAY, fontSize: 20, fontWeight: 600, color: C.ink }}>{title}</div>
      </div>
      {action}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Landing Page                                                       */
/* ------------------------------------------------------------------ */
function Landing({ onEnter }) {
  const [activePreview, setActivePreview] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setActivePreview((p) => (p + 1) % 4), 2600);
    return () => clearInterval(id);
  }, []);
  const steps = ["Discover", "Enrich", "Analyze", "Score", "Organize", "Outreach"];
  const previewLabels = ["Searching companies", "Finding decision makers", "Enriching data", "Calculating lead scores"];

  return (
    <div className="lp-scope" style={{ background: C.bg, minHeight: "100%" }}>
      {/* Nav */}
      <div style={{ position: "sticky", top: 0, zIndex: 30, background: "rgba(246,247,249,0.85)", backdropFilter: "blur(8px)", borderBottom: `1px solid ${C.border}` }}>
        <div style={{ maxWidth: 1180, margin: "0 auto", padding: "14px 24px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
            <div style={{ width: 28, height: 28, borderRadius: 8, background: C.primary, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Radar size={16} color="#fff" strokeWidth={2.4} />
            </div>
            <span style={{ fontFamily: FONT_DISPLAY, fontWeight: 700, fontSize: 17 }}>LeadPilot</span>
          </div>
          <div className="lp-hide-mobile" style={{ display: "flex", gap: 28, fontSize: 14, fontWeight: 500, color: C.ink2 }}>
            <span>Product</span><span>Features</span><span>Pricing</span><span>Resources</span>
          </div>
          <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
            <span className="lp-hide-mobile" style={{ fontSize: 14, fontWeight: 600, color: C.ink2, cursor: "pointer" }}>Log in</span>
            <Btn size="sm" onClick={onEnter}>Get Started</Btn>
          </div>
        </div>
      </div>

      {/* Hero */}
      <div style={{ maxWidth: 1180, margin: "0 auto", padding: "72px 24px 40px", textAlign: "center" }}>
        <div className="lp-fadeup" style={{ display: "inline-flex", alignItems: "center", gap: 6, background: C.accentSoft, color: C.accentDeep, padding: "6px 12px", borderRadius: 999, fontSize: 13, fontWeight: 600, marginBottom: 22 }}>
          <Sparkles size={13} /> AI-qualified prospects, updated daily
        </div>
        <h1 className="lp-fadeup" style={{ fontFamily: FONT_DISPLAY, fontWeight: 700, fontSize: "clamp(32px, 5vw, 56px)", lineHeight: 1.08, letterSpacing: -0.5, margin: "0 0 20px", animationDelay: ".05s" }}>
          Find the right prospects.<br />Before your competitors do.
        </h1>
        <p className="lp-fadeup" style={{ maxWidth: 620, margin: "0 auto 30px", fontSize: 17, color: C.muted, lineHeight: 1.6, animationDelay: ".1s" }}>
          LeadPilot discovers, researches, enriches, scores, and organizes B2B prospects — combining a lead database, AI researcher, and outreach workspace in one place.
        </p>
        <div className="lp-fadeup" style={{ display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap", animationDelay: ".15s" }}>
          <Btn variant="accent" icon={ArrowRight} onClick={onEnter}>Start Finding Leads</Btn>
          <Btn variant="ghost">See How It Works</Btn>
        </div>

        {/* Product preview */}
        <div className="lp-fadeup" style={{ marginTop: 56, animationDelay: ".2s" }}>
          <Card style={{ maxWidth: 920, margin: "0 auto", padding: 20, textAlign: "left", boxShadow: "0 20px 60px -20px rgba(28,39,69,0.25)" }}>
            <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
              {previewLabels.map((l, i) => (
                <div key={l} style={{
                  flex: 1, padding: "9px 10px", borderRadius: 8, fontSize: 12, fontWeight: 600,
                  background: i === activePreview ? C.primarySoft : C.surfaceAlt,
                  color: i === activePreview ? C.primary : C.faint,
                  border: `1px solid ${i === activePreview ? C.primary : C.border}`,
                  transition: "all .3s ease", textAlign: "center",
                }}>{l}</div>
              ))}
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 14 }}>
              <div style={{ border: `1px solid ${C.border}`, borderRadius: 10, overflow: "hidden" }}>
                {PEOPLE.slice(0, 5).map((p, i) => (
                  <div key={p.id} className="lp-stagger-row" style={{ animationDelay: `${i * 0.05}s`, display: "flex", alignItems: "center", gap: 10, padding: "9px 12px", borderBottom: i < 4 ? `1px solid ${C.border}` : "none" }}>
                    <div style={{ width: 26, height: 26, borderRadius: 999, background: C.primarySoft, color: C.primary, fontSize: 11, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center" }}>{p.name[0]}</div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: 12.5, fontWeight: 600, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{p.name}</div>
                      <div style={{ fontSize: 11, color: C.muted, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{p.title} · {p.company}</div>
                    </div>
                    <div style={{ fontFamily: FONT_MONO, fontSize: 12, fontWeight: 700, color: p.score >= 80 ? C.accentDeep : C.primary }}>{p.score}</div>
                  </div>
                ))}
              </div>
              <div style={{ border: `1px solid ${C.border}`, borderRadius: 10, padding: 14, background: C.surfaceAlt }}>
                <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12, fontWeight: 700, color: C.accentDeep, marginBottom: 10 }}>
                  <Zap size={13} /> AI Insight
                </div>
                <div style={{ fontSize: 12.5, color: C.ink2, lineHeight: 1.6 }}>
                  42 leads match your ICP but haven't been enriched. 18 companies show strong buying signals this week.
                </div>
                <div style={{ marginTop: 14, display: "flex", gap: 8 }}>
                  <ScoreRing score={91} size={44} stroke={4} />
                  <div style={{ fontSize: 11.5, color: C.muted, alignSelf: "center" }}>Average ICP fit across your saved search</div>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>

      {/* Workflow */}
      <div style={{ maxWidth: 1180, margin: "0 auto", padding: "70px 24px" }}>
        <SectionTitle eyebrow="How it works" title="One workspace, six connected steps" />
        <div style={{ display: "flex", gap: 0, overflowX: "auto" }} className="lp-table-wrap">
          {steps.map((s, i) => (
            <React.Fragment key={s}>
              <div style={{ minWidth: 140, textAlign: "center" }}>
                <div style={{ width: 42, height: 42, margin: "0 auto 10px", borderRadius: 999, background: i === 0 ? C.primary : C.surface, border: `1px solid ${i === 0 ? C.primary : C.border}`, color: i === 0 ? "#fff" : C.ink2, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: FONT_MONO, fontWeight: 700, fontSize: 13 }}>
                  {String(i + 1).padStart(2, "0")}
                </div>
                <div style={{ fontSize: 13.5, fontWeight: 600 }}>{s}</div>
              </div>
              {i < steps.length - 1 && <div style={{ flex: 1, alignSelf: "center", height: 1, background: C.border, minWidth: 16 }} />}
            </React.Fragment>
          ))}
        </div>
      </div>

      {/* Features */}
      <div style={{ maxWidth: 1180, margin: "0 auto", padding: "20px 24px 70px" }}>
        <SectionTitle eyebrow="Platform" title="Everything a modern sales team needs to prospect" />
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(260px,1fr))", gap: 16 }}>
          {[
            { icon: Database, title: "Prospect database", body: "Search 60M+ verified companies and contacts with granular firmographic and intent filters." },
            { icon: BrainCircuit, title: "AI research assistant", body: "Describe your ideal customer in plain language and let AI translate it into structured search filters." },
            { icon: ShieldCheck, title: "Verification built in", body: "Every email and phone number is checked for deliverability before it reaches your list." },
            { icon: TrendingUp, title: "Explainable lead scoring", body: "Scores break down into ICP fit, buying intent, and data quality — never a black box." },
            { icon: Megaphone, title: "Outreach preparation", body: "Generate personalized drafts from verified data, then review before anything goes out." },
            { icon: Plug, title: "Works with your stack", body: "Push enriched leads to Salesforce, HubSpot, Sheets, or Slack in a couple of clicks." },
          ].map((f, i) => (
            <Card key={f.title} className="lp-fadeup" style={{ padding: 20, animationDelay: `${i * 0.05}s` }}>
              <div style={{ width: 34, height: 34, borderRadius: 9, background: C.primarySoft, display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 12 }}>
                <f.icon size={17} color={C.primary} strokeWidth={2} />
              </div>
              <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 6 }}>{f.title}</div>
              <div style={{ fontSize: 13.5, color: C.muted, lineHeight: 1.55 }}>{f.body}</div>
            </Card>
          ))}
        </div>
      </div>

      {/* Social proof */}
      <div style={{ borderTop: `1px solid ${C.border}`, borderBottom: `1px solid ${C.border}`, background: C.surface }}>
        <div style={{ maxWidth: 1180, margin: "0 auto", padding: "36px 24px", display: "flex", gap: 40, flexWrap: "wrap", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ fontSize: 13, color: C.muted, fontWeight: 600 }}>Trusted by revenue teams at growth-stage companies</div>
          <div style={{ display: "flex", gap: 32, flexWrap: "wrap" }}>
            {["Northwind", "Fintra", "Cartway", "Vireo", "Cipher", "Portside"].map((n) => (
              <span key={n} style={{ fontFamily: FONT_DISPLAY, fontWeight: 700, fontSize: 15, color: C.faint }}>{n}</span>
            ))}
          </div>
        </div>
      </div>

      {/* Pricing */}
      <div style={{ maxWidth: 1180, margin: "0 auto", padding: "70px 24px" }}>
        <SectionTitle eyebrow="Pricing" title="Plans that scale with your pipeline" />
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px,1fr))", gap: 16 }}>
          {[
            { name: "Free", price: "$0", credits: "50 credits/mo", cta: "Start free", feat: ["Basic search filters", "CSV export", "1 seat"] },
            { name: "Starter", price: "$49", credits: "1,000 credits/mo", cta: "Choose Starter", feat: ["Full filters + intent signals", "Email verification", "3 seats"] },
            { name: "Professional", price: "$149", credits: "5,000 credits/mo", featured: true, cta: "Choose Professional", feat: ["AI research assistant", "Lead scoring & ICP builder", "10 seats", "CRM integrations"] },
            { name: "Business", price: "Custom", credits: "Unlimited credits", cta: "Talk to sales", feat: ["Dedicated data pipeline", "SSO & audit logs", "Unlimited seats"] },
          ].map((p) => (
            <Card key={p.name} style={{
              padding: 22, borderColor: p.featured ? C.primary : C.border,
              boxShadow: p.featured ? `0 0 0 1px ${C.primary}` : "none", position: "relative",
            }}>
              {p.featured && <div style={{ position: "absolute", top: -11, left: 20, background: C.primary, color: "#fff", fontSize: 11, fontWeight: 700, padding: "3px 10px", borderRadius: 999 }}>Most popular</div>}
              <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 4 }}>{p.name}</div>
              <div style={{ fontFamily: FONT_DISPLAY, fontSize: 30, fontWeight: 700, marginBottom: 2 }}>{p.price}{p.price !== "Custom" && <span style={{ fontSize: 13, color: C.muted, fontWeight: 500 }}>/mo</span>}</div>
              <div style={{ fontSize: 12.5, color: C.muted, marginBottom: 16 }}>{p.credits}</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 18 }}>
                {p.feat.map((f) => (
                  <div key={f} style={{ display: "flex", gap: 7, fontSize: 13, color: C.ink2 }}>
                    <Check size={14} color={C.accent} style={{ flexShrink: 0, marginTop: 2 }} /> {f}
                  </div>
                ))}
              </div>
              <Btn variant={p.featured ? "accent" : "ghost"} style={{ width: "100%", justifyContent: "center" }}>{p.cta}</Btn>
            </Card>
          ))}
        </div>
      </div>

      {/* Final CTA */}
      <div style={{ maxWidth: 1180, margin: "0 auto 70px", padding: "0 24px" }}>
        <Card style={{ background: C.primary, border: "none", padding: "48px 32px", textAlign: "center", position: "relative", overflow: "hidden" }}>
          <div className="lp-spin" style={{ position: "absolute", top: -60, right: -60, width: 220, height: 220, borderRadius: "50%", border: `1px solid rgba(255,255,255,0.12)` }} />
          <div style={{ fontFamily: FONT_DISPLAY, fontSize: 26, fontWeight: 700, color: "#fff", marginBottom: 10, position: "relative" }}>Your next best customer is already searchable.</div>
          <div style={{ color: "rgba(255,255,255,0.75)", marginBottom: 22, position: "relative" }}>Set up your first ICP in under five minutes.</div>
          <div style={{ position: "relative" }}><Btn variant="accent" icon={ArrowRight} onClick={onEnter}>Start Finding Leads</Btn></div>
        </Card>
      </div>

      <div style={{ borderTop: `1px solid ${C.border}`, padding: "24px", textAlign: "center", fontSize: 12.5, color: C.faint }}>
        © 2026 LeadPilot, Inc. — a prototype interface for demonstration.
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Filter panel (Find Leads)                                          */
/* ------------------------------------------------------------------ */
function FilterChip({ label, onRemove }) {
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "5px 8px 5px 10px", borderRadius: 999, background: C.primarySoft, color: C.primary, fontSize: 12.5, fontWeight: 600 }}>
      {label}
      <X size={12} style={{ cursor: "pointer" }} onClick={onRemove} />
    </span>
  );
}

function FilterGroup({ title, options, selected, toggle }) {
  return (
    <div style={{ marginBottom: 18 }}>
      <div style={{ fontSize: 12, fontWeight: 700, color: C.muted, textTransform: "uppercase", letterSpacing: 0.3, marginBottom: 8 }}>{title}</div>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
        {options.map((o) => {
          const active = selected.includes(o);
          return (
            <span key={o} onClick={() => toggle(o)} className="lp-btn" style={{
              padding: "5px 10px", borderRadius: 8, fontSize: 12.5, fontWeight: 600,
              background: active ? C.primary : C.surfaceAlt, color: active ? "#fff" : C.ink2,
              border: `1px solid ${active ? C.primary : C.border}`,
            }}>{o}</span>
          );
        })}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Prospect Drawer                                                     */
/* ------------------------------------------------------------------ */
function ProspectDrawer({ person, onClose }) {
  if (!person) return null;
  const co = COMPANIES.find((c) => c.id === person.companyId);
  const factors = [
    { label: "ICP Fit", value: person.icpFit },
    { label: "Buying Intent", value: person.buyingIntent },
    { label: "Company Fit", value: person.companyFit },
    { label: "Role Fit", value: person.roleFit },
    { label: "Data Quality", value: person.dataQuality },
  ];
  return (
    <>
      <div className="lp-overlay-in" onClick={onClose} style={{ position: "fixed", inset: 0, background: "rgba(18,22,28,0.35)", zIndex: 40 }} />
      <div className="lp-drawer-in lp-scrollbar" style={{
        position: "fixed", top: 0, right: 0, height: "100%", width: "min(440px, 100vw)",
        background: C.surface, zIndex: 41, overflowY: "auto", boxShadow: "-16px 0 40px rgba(0,0,0,0.12)",
      }}>
        <div style={{ padding: "18px 20px", borderBottom: `1px solid ${C.border}`, display: "flex", alignItems: "center", justifyContent: "space-between", position: "sticky", top: 0, background: C.surface, zIndex: 1 }}>
          <span style={{ fontSize: 13, fontWeight: 700, color: C.muted }}>Prospect profile</span>
          <X size={18} style={{ cursor: "pointer" }} onClick={onClose} />
        </div>
        <div style={{ padding: 22 }}>
          <div style={{ display: "flex", gap: 14, alignItems: "center", marginBottom: 18 }}>
            <div style={{ width: 54, height: 54, borderRadius: 999, background: C.primarySoft, color: C.primary, fontFamily: FONT_DISPLAY, fontWeight: 700, fontSize: 20, display: "flex", alignItems: "center", justifyContent: "center" }}>
              {person.name[0]}
            </div>
            <div>
              <div style={{ fontFamily: FONT_DISPLAY, fontWeight: 700, fontSize: 18 }}>{person.name}</div>
              <div style={{ fontSize: 13.5, color: C.muted }}>{person.title} · {person.company}</div>
            </div>
          </div>

          <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
            <Btn size="sm" icon={Mail}>Email</Btn>
            <Btn size="sm" variant="ghost" icon={Phone}>Call</Btn>
            <Btn size="sm" variant="ghost" icon={Linkedin}>LinkedIn</Btn>
          </div>

          <Card style={{ padding: 16, marginBottom: 16, background: C.surfaceAlt }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 4 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12.5, fontWeight: 700, color: C.accentDeep }}>
                <Sparkles size={13} /> AI Lead Summary
              </div>
            </div>
            <div style={{ fontSize: 13, color: C.ink2, lineHeight: 1.6 }}>
              Strong match for your ICP — {person.company} shows {person.intent.toLowerCase()} and uses technology relevant to your product. {person.name.split(" ")[0]} sits in a {person.seniority.toLowerCase()} {person.dept.toLowerCase()} role, typical for your closed-won accounts.
            </div>
          </Card>

          <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 16, padding: 16, border: `1px solid ${C.border}`, borderRadius: 12 }}>
            <ScoreRing score={person.score} size={64} />
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 6 }}>AI Lead Score</div>
              {factors.map((f) => (
                <div key={f.label} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
                  <div style={{ fontSize: 11, color: C.muted, width: 82, flexShrink: 0 }}>{f.label}</div>
                  <div style={{ flex: 1, height: 5, borderRadius: 4, background: C.border, overflow: "hidden" }}>
                    <div style={{ width: `${f.value}%`, height: "100%", background: C.primary, borderRadius: 4 }} />
                  </div>
                  <div style={{ fontFamily: FONT_MONO, fontSize: 11, color: C.ink2, width: 26, textAlign: "right" }}>{f.value}</div>
                </div>
              ))}
            </div>
          </div>

          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: C.muted, textTransform: "uppercase", marginBottom: 10 }}>Contact</div>
            {[
              { icon: Mail, label: person.email, tag: person.verification },
              { icon: Phone, label: person.phone },
              { icon: Linkedin, label: person.linkedin },
              { icon: MapPin, label: person.location },
            ].map((r, i) => (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: 9, padding: "8px 0", borderBottom: i < 3 ? `1px solid ${C.border}` : "none" }}>
                <r.icon size={14} color={C.muted} />
                <span style={{ fontSize: 13, color: C.ink2, flex: 1 }}>{r.label}</span>
                {r.tag && <Badge tone={r.tag === "Verified" ? "accent" : "warn"}>{r.tag}</Badge>}
              </div>
            ))}
          </div>

          {co && (
            <div>
              <div style={{ fontSize: 12, fontWeight: 700, color: C.muted, textTransform: "uppercase", marginBottom: 10 }}>Company</div>
              <Card style={{ padding: 14 }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 10 }}>
                  <div style={{ fontWeight: 700, fontSize: 14 }}>{co.name}</div>
                  <Badge tone="primary">{co.industry}</Badge>
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, fontSize: 12.5 }}>
                  <div><div style={{ color: C.faint }}>Employees</div><div style={{ fontWeight: 600 }}>{co.employees}</div></div>
                  <div><div style={{ color: C.faint }}>Revenue</div><div style={{ fontWeight: 600 }}>{co.revenue}</div></div>
                  <div><div style={{ color: C.faint }}>HQ</div><div style={{ fontWeight: 600 }}>{co.location}</div></div>
                  <div><div style={{ color: C.faint }}>Founded</div><div style={{ fontWeight: 600 }}>{co.founded}</div></div>
                  <div><div style={{ color: C.faint }}>Funding</div><div style={{ fontWeight: 600 }}>{co.funding}</div></div>
                  <div><div style={{ color: C.faint }}>Growth</div><div style={{ fontWeight: 600, color: C.accentDeep }}>{co.growth}</div></div>
                </div>
                <div style={{ marginTop: 10, display: "flex", gap: 6, flexWrap: "wrap" }}>
                  {co.tech.map((t) => <Badge key={t}>{t}</Badge>)}
                </div>
              </Card>
            </div>
          )}
        </div>
      </div>
    </>
  );
}

/* ------------------------------------------------------------------ */
/*  Find Leads / Results Table                                          */
/* ------------------------------------------------------------------ */
function FindLeads({ onOpenPerson }) {
  const [selIndustry, setSelIndustry] = useState(["SaaS"]);
  const [selSeniority, setSelSeniority] = useState(["VP"]);
  const [selIntent, setSelIntent] = useState([]);
  const [searching, setSearching] = useState(false);
  const [searched, setSearched] = useState(true);
  const [checked, setChecked] = useState([]);
  const [stage, setStage] = useState(4);

  const toggle = (setFn, arr) => (v) => setFn(arr.includes(v) ? arr.filter((x) => x !== v) : [...arr, v]);

  const results = useMemo(() => {
    return PEOPLE.filter((p) => {
      if (selIndustry.length && !selIndustry.includes(p.industry)) return false;
      if (selSeniority.length && !selSeniority.includes(p.seniority)) return false;
      if (selIntent.length && !selIntent.some((i) => p.intent.includes(i))) return false;
      return true;
    });
  }, [selIndustry, selSeniority, selIntent]);

  const runSearch = () => {
    setSearching(true);
    setStage(0);
    let s = 0;
    const id = setInterval(() => {
      s += 1;
      setStage(s);
      if (s >= 4) { clearInterval(id); setSearching(false); setSearched(true); }
    }, 420);
  };

  const stages = ["Searching companies", "Finding decision makers", "Enriching data", "Verifying contacts", "Calculating lead scores"];
  const allChips = [...selIndustry.map((v) => ({ v, group: "industry" })), ...selSeniority.map((v) => ({ v, group: "seniority" })), ...selIntent.map((v) => ({ v, group: "intent" }))];

  return (
    <div style={{ display: "flex", gap: 20, alignItems: "flex-start" }}>
      <Card style={{ width: 260, flexShrink: 0, padding: 18, position: "sticky", top: 84 }} className="lp-hide-mobile">
        <div style={{ display: "flex", alignItems: "center", gap: 7, marginBottom: 16, fontWeight: 700, fontSize: 14 }}>
          <Filter size={15} color={C.primary} /> Filters
        </div>
        <FilterGroup title="Industry" options={INDUSTRIES} selected={selIndustry} toggle={toggle(setSelIndustry, selIndustry)} />
        <FilterGroup title="Seniority" options={["C-Level", "VP", "Head", "Director"]} selected={selSeniority} toggle={toggle(setSelSeniority, selSeniority)} />
        <FilterGroup title="Intent signal" options={["Hiring", "New tech", "Website", "funding".length ? "Funding" : "Funding"]} selected={selIntent} toggle={toggle(setSelIntent, selIntent)} />
        <Btn style={{ width: "100%", justifyContent: "center", marginTop: 6 }} onClick={runSearch}>Search Leads</Btn>
        <Btn variant="ghost" style={{ width: "100%", justifyContent: "center", marginTop: 8 }}>Save Search</Btn>
      </Card>

      <div style={{ flex: 1, minWidth: 0 }}>
        <SectionTitle
          eyebrow="Find Leads"
          title={`${results.length.toLocaleString()} prospects match your filters`}
          action={<div style={{ display: "flex", gap: 8 }}>
            <Btn variant="ghost" icon={Download} size="sm">Export CSV</Btn>
            <Btn variant="subtle" icon={Plus} size="sm">Add to list</Btn>
          </div>}
        />

        {allChips.length > 0 && (
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 14 }}>
            {allChips.map((c) => (
              <FilterChip key={c.group + c.v} label={c.v} onRemove={() => {
                if (c.group === "industry") setSelIndustry(selIndustry.filter((x) => x !== c.v));
                if (c.group === "seniority") setSelSeniority(selSeniority.filter((x) => x !== c.v));
                if (c.group === "intent") setSelIntent(selIntent.filter((x) => x !== c.v));
              }} />
            ))}
          </div>
        )}

        {searching && (
          <Card style={{ padding: 18, marginBottom: 16 }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 10 }}>
              {stages.map((s, i) => (
                <div key={s} style={{ fontSize: 11.5, fontWeight: 600, color: i <= stage ? C.primary : C.faint, display: "flex", alignItems: "center", gap: 5 }}>
                  {i < stage ? <Check size={12} color={C.accent} /> : i === stage ? <CircleDot size={12} className="lp-signal" color={C.primary} /> : <CircleDot size={12} color={C.faint} />}
                  {s}
                </div>
              ))}
            </div>
            <div style={{ height: 6, borderRadius: 4, background: C.border, overflow: "hidden" }}>
              <div style={{ width: `${(stage / 4) * 100}%`, height: "100%", background: `linear-gradient(90deg, ${C.primary}, ${C.accent})`, borderRadius: 4, transition: "width .4s ease" }} />
            </div>
          </Card>
        )}

        {searched && !searching && (
          <Card className="lp-table-wrap lp-scrollbar" style={{ overflow: "hidden" }}>
            <table style={{ width: "100%", fontSize: 13 }}>
              <thead>
                <tr style={{ background: C.surfaceAlt, borderBottom: `1px solid ${C.border}` }}>
                  {["", "Name", "Title", "Company", "Location", "Score", "Intent", "Verification", "Updated", ""].map((h) => (
                    <th key={h} style={{ textAlign: "left", padding: "10px 12px", fontSize: 11.5, color: C.muted, fontWeight: 700, textTransform: "uppercase", letterSpacing: 0.3, whiteSpace: "nowrap" }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {results.map((p, i) => (
                  <tr key={p.id} className="lp-row lp-stagger-row" style={{ borderBottom: `1px solid ${C.border}`, cursor: "pointer", animationDelay: `${Math.min(i, 10) * 0.03}s` }} onClick={() => onOpenPerson(p)}>
                    <td style={{ padding: "10px 12px" }} onClick={(e) => e.stopPropagation()}>
                      <input type="checkbox" checked={checked.includes(p.id)} onChange={() => setChecked(checked.includes(p.id) ? checked.filter((x) => x !== p.id) : [...checked, p.id])} />
                    </td>
                    <td style={{ padding: "10px 12px", fontWeight: 600, whiteSpace: "nowrap" }}>{p.name}</td>
                    <td style={{ padding: "10px 12px", color: C.ink2, whiteSpace: "nowrap" }}>{p.title}</td>
                    <td style={{ padding: "10px 12px", color: C.ink2, whiteSpace: "nowrap" }}>{p.company}</td>
                    <td style={{ padding: "10px 12px", color: C.muted, whiteSpace: "nowrap" }}>{p.location}</td>
                    <td style={{ padding: "10px 12px" }}>
                      <span style={{ fontFamily: FONT_MONO, fontWeight: 700, color: p.score >= 80 ? C.accentDeep : p.score >= 60 ? C.primary : C.warn }}>{p.score}</span>
                    </td>
                    <td style={{ padding: "10px 12px", whiteSpace: "nowrap" }}><Badge tone="accent" dot>{p.intent}</Badge></td>
                    <td style={{ padding: "10px 12px", whiteSpace: "nowrap" }}>
                      <Badge tone={p.verification === "Verified" ? "accent" : p.verification === "Found" ? "primary" : "warn"}>{p.verification}</Badge>
                    </td>
                    <td style={{ padding: "10px 12px", color: C.faint, whiteSpace: "nowrap" }}>{p.lastUpdated}</td>
                    <td style={{ padding: "10px 12px" }}><MoreHorizontal size={15} color={C.faint} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Card>
        )}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Overview                                                            */
/* ------------------------------------------------------------------ */
function KPI({ label, value, delta, format, icon: Icon }) {
  return (
    <Card className="lp-fadeup" style={{ padding: 16 }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
        <div style={{ width: 30, height: 30, borderRadius: 8, background: C.primarySoft, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <Icon size={15} color={C.primary} />
        </div>
        {delta && <span style={{ fontSize: 11.5, fontWeight: 700, color: C.accentDeep, display: "flex", alignItems: "center", gap: 2 }}><TrendingUp size={11} />{delta}</span>}
      </div>
      <div style={{ fontFamily: FONT_MONO, fontSize: 24, fontWeight: 600 }}><CountUp value={value} format={format} /></div>
      <div style={{ fontSize: 12.5, color: C.muted, marginTop: 2 }}>{label}</div>
    </Card>
  );
}

function Overview({ onOpenPerson, goFindLeads }) {
  return (
    <div>
      <SectionTitle eyebrow="Workspace" title="Good morning — here's your prospecting snapshot" action={<Btn icon={Plus} size="sm" onClick={goFindLeads}>New search</Btn>} />
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(160px,1fr))", gap: 14, marginBottom: 20 }}>
        <KPI label="Total leads" value={4820} delta="+12.4%" icon={Users} />
        <KPI label="New this week" value={338} delta="+8.1%" icon={Sparkles} />
        <KPI label="Verified emails" value={3162} delta="+5.6%" icon={ShieldCheck} />
        <KPI label="Companies found" value={612} delta="+3.2%" icon={Building2} />
        <KPI label="High-intent leads" value={219} delta="+21%" icon={Zap} />
        <KPI label="Avg. lead score" value={71} format={(v) => Math.round(v)} icon={TrendingUp} />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1.6fr 1fr", gap: 16, marginBottom: 16 }}>
        <Card style={{ padding: 18 }}>
          <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 12 }}>Leads discovered over time</div>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={LEADS_OVER_TIME}>
              <defs>
                <linearGradient id="leadFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={C.accent} stopOpacity={0.35} />
                  <stop offset="100%" stopColor={C.accent} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid vertical={false} stroke={C.border} />
              <XAxis dataKey="d" tick={{ fontSize: 11, fill: C.faint }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: C.faint }} axisLine={false} tickLine={false} width={30} />
              <Tooltip contentStyle={{ borderRadius: 8, border: `1px solid ${C.border}`, fontSize: 12 }} />
              <Area type="monotone" dataKey="leads" stroke={C.accentDeep} strokeWidth={2} fill="url(#leadFill)" />
            </AreaChart>
          </ResponsiveContainer>
        </Card>
        <Card style={{ padding: 18 }}>
          <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 12 }}>Lead quality distribution</div>
          <ResponsiveContainer width="100%" height={180}>
            <PieChart>
              <Pie data={QUALITY_DIST} dataKey="value" nameKey="name" innerRadius={45} outerRadius={72} paddingAngle={2}>
                {QUALITY_DIST.map((q) => <Cell key={q.name} fill={q.color} />)}
              </Pie>
              <Tooltip contentStyle={{ borderRadius: 8, border: `1px solid ${C.border}`, fontSize: 12 }} />
            </PieChart>
          </ResponsiveContainer>
          <div style={{ display: "flex", flexDirection: "column", gap: 5, marginTop: 4 }}>
            {QUALITY_DIST.map((q) => (
              <div key={q.name} style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 11.5, color: C.ink2 }}>
                <span style={{ width: 7, height: 7, borderRadius: 999, background: q.color }} /> {q.name}
              </div>
            ))}
          </div>
        </Card>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 20 }}>
        <Card style={{ padding: 18 }}>
          <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 12 }}>Industry breakdown</div>
          <ResponsiveContainer width="100%" height={190}>
            <BarChart data={INDUSTRY_BREAKDOWN} layout="vertical" margin={{ left: 10 }}>
              <XAxis type="number" hide />
              <YAxis type="category" dataKey="name" tick={{ fontSize: 11, fill: C.ink2 }} axisLine={false} tickLine={false} width={90} />
              <Tooltip contentStyle={{ borderRadius: 8, border: `1px solid ${C.border}`, fontSize: 12 }} />
              <Bar dataKey="value" radius={[0, 5, 5, 0]} fill={C.primary} />
            </BarChart>
          </ResponsiveContainer>
        </Card>
        <Card style={{ padding: 18 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6, fontWeight: 700, fontSize: 14, marginBottom: 12, color: C.accentDeep }}>
            <Sparkles size={15} /> Recommended actions
          </div>
          {[
            "42 leads match your ICP but haven't been enriched.",
            "18 companies show strong buying signals this week.",
            "Your highest-performing industry this month is SaaS.",
            "9 verified contacts in \"High Intent Leads\" have no outreach yet.",
          ].map((t, i) => (
            <div key={i} style={{ display: "flex", gap: 9, padding: "9px 0", borderBottom: i < 3 ? `1px solid ${C.border}` : "none", fontSize: 13, color: C.ink2 }}>
              <ArrowUpRight size={14} color={C.accent} style={{ flexShrink: 0, marginTop: 2 }} /> {t}
            </div>
          ))}
        </Card>
      </div>

      <Card style={{ padding: 18 }}>
        <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 10 }}>Recent activity</div>
        {PEOPLE.slice(0, 6).map((p, i) => (
          <div key={p.id} onClick={() => onOpenPerson(p)} className="lp-row" style={{ display: "flex", alignItems: "center", gap: 10, padding: "9px 4px", borderBottom: i < 5 ? `1px solid ${C.border}` : "none", cursor: "pointer", borderRadius: 8 }}>
            <Clock size={13} color={C.faint} />
            <span style={{ fontSize: 13, color: C.ink2, flex: 1 }}><b>{p.name}</b> at {p.company} was added to your database</span>
            <span style={{ fontSize: 11.5, color: C.faint }}>{p.lastUpdated}</span>
          </div>
        ))}
      </Card>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  AI Research                                                         */
/* ------------------------------------------------------------------ */
function AIResearch() {
  const [query, setQuery] = useState("Find SaaS companies in the UK with 50-500 employees that are hiring sales representatives.");
  const [running, setRunning] = useState(false);
  const [done, setDone] = useState(true);
  const filters = [
    { k: "Industry", v: "SaaS" },
    { k: "Location", v: "United Kingdom" },
    { k: "Employees", v: "50 – 500" },
    { k: "Hiring activity", v: "Sales roles, active" },
  ];
  const run = () => { setRunning(true); setDone(false); setTimeout(() => { setRunning(false); setDone(true); }, 1600); };
  return (
    <div>
      <SectionTitle eyebrow="AI Research" title="Describe your ideal customer in plain language" />
      <Card style={{ padding: 18, marginBottom: 18 }}>
        <textarea value={query} onChange={(e) => setQuery(e.target.value)} rows={2} style={{
          width: "100%", border: `1px solid ${C.border}`, borderRadius: 10, padding: 12, fontSize: 14,
          fontFamily: FONT_BODY, resize: "vertical", color: C.ink,
        }} />
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 10 }}>
          <span style={{ fontSize: 12, color: C.faint }}>The AI turns this into structured, editable filters — never invented data.</span>
          <Btn icon={Sparkles} onClick={run}>{running ? "Interpreting…" : "Run research"}</Btn>
        </div>
      </Card>

      {running && (
        <Card style={{ padding: 24, marginBottom: 18, textAlign: "center" }}>
          <div style={{ display: "flex", justifyContent: "center", gap: 6, marginBottom: 10 }}>
            {[0, 1, 2].map((i) => (
              <span key={i} className="lp-signal" style={{ width: 8, height: 8, borderRadius: 999, background: C.primary, animationDelay: `${i * 0.2}s` }} />
            ))}
          </div>
          <div style={{ fontSize: 13, color: C.muted }}>Understanding request → building filters → matching companies…</div>
        </Card>
      )}

      {done && (
        <>
          <Card style={{ padding: 18, marginBottom: 18 }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: C.muted, textTransform: "uppercase", marginBottom: 10 }}>Filters created (editable)</div>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              {filters.map((f) => (
                <span key={f.k} style={{ fontSize: 12.5, padding: "6px 10px", borderRadius: 8, background: C.primarySoft, color: C.primary, fontWeight: 600 }}>
                  {f.k}: <span style={{ fontWeight: 700 }}>{f.v}</span>
                </span>
              ))}
            </div>
          </Card>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(200px,1fr))", gap: 12 }}>
            {[
              { label: "Companies discovered", value: 34, tone: "primary" },
              { label: "People discovered", value: 118, tone: "primary" },
              { label: "Enriched", value: 96, tone: "accent" },
              { label: "AI-qualified", value: 41, tone: "accent" },
            ].map((s) => (
              <Card key={s.label} style={{ padding: 16 }}>
                <div style={{ fontFamily: FONT_MONO, fontSize: 22, fontWeight: 700, color: s.tone === "accent" ? C.accentDeep : C.primary }}><CountUp value={s.value} /></div>
                <div style={{ fontSize: 12.5, color: C.muted }}>{s.label}</div>
              </Card>
            ))}
          </div>
          <div style={{ marginTop: 14, fontSize: 12, color: C.faint, display: "flex", gap: 14 }}>
            <span style={{ display: "flex", alignItems: "center", gap: 5 }}><span style={{ width: 8, height: 8, borderRadius: 999, background: C.accent }} /> Verified data</span>
            <span style={{ display: "flex", alignItems: "center", gap: 5 }}><span style={{ width: 8, height: 8, borderRadius: 999, background: C.primary }} /> Estimated data</span>
            <span style={{ display: "flex", alignItems: "center", gap: 5 }}><span style={{ width: 8, height: 8, borderRadius: 999, background: C.warn }} /> AI-generated analysis</span>
          </div>
        </>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Lists                                                               */
/* ------------------------------------------------------------------ */
function Lists({ onOpenPerson }) {
  const [active, setActive] = useState(LISTS[0].id);
  const currentList = LISTS.find((l) => l.id === active);
  const members = PEOPLE.slice(0, currentList.count > 12 ? 8 : 5);
  return (
    <div>
      <SectionTitle eyebrow="Lead Lists" title="Organized prospects, ready for outreach" action={<Btn icon={Plus} size="sm">Create list</Btn>} />
      <div style={{ display: "grid", gridTemplateColumns: "260px 1fr", gap: 18 }}>
        <Card style={{ padding: 8 }}>
          {LISTS.map((l) => (
            <div key={l.id} onClick={() => setActive(l.id)} className="lp-navitem" style={{
              padding: "10px 12px", borderRadius: 9, cursor: "pointer", marginBottom: 2,
              background: active === l.id ? C.primarySoft : "transparent",
            }}>
              <div style={{ fontSize: 13.5, fontWeight: 600, color: active === l.id ? C.primary : C.ink }}>{l.name}</div>
              <div style={{ fontSize: 11.5, color: C.faint }}>{l.count} leads · updated {l.updated}</div>
            </div>
          ))}
        </Card>
        <Card style={{ padding: 0, overflow: "hidden" }}>
          <div style={{ padding: 16, borderBottom: `1px solid ${C.border}`, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div>
              <div style={{ fontWeight: 700, fontSize: 15 }}>{currentList.name}</div>
              <div style={{ fontSize: 12, color: C.faint }}>{currentList.count} leads</div>
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              <Btn size="sm" variant="ghost" icon={Download}>Export</Btn>
              <Btn size="sm" variant="subtle">Share</Btn>
            </div>
          </div>
          {members.map((p, i) => (
            <div key={p.id} onClick={() => onOpenPerson(p)} className="lp-row" style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 16px", borderBottom: i < members.length - 1 ? `1px solid ${C.border}` : "none", cursor: "pointer" }}>
              <div style={{ width: 30, height: 30, borderRadius: 999, background: C.primarySoft, color: C.primary, fontSize: 12, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center" }}>{p.name[0]}</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13.5, fontWeight: 600 }}>{p.name}</div>
                <div style={{ fontSize: 12, color: C.muted }}>{p.title} · {p.company}</div>
              </div>
              <Badge tone={p.score >= 80 ? "accent" : "primary"}>{p.score}</Badge>
            </div>
          ))}
        </Card>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Companies                                                           */
/* ------------------------------------------------------------------ */
function Companies() {
  return (
    <div>
      <SectionTitle eyebrow="Company Database" title="612 companies discovered" action={<Btn icon={Download} size="sm" variant="ghost">Export</Btn>} />
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(260px,1fr))", gap: 14 }}>
        {COMPANIES.map((c, i) => (
          <Card key={c.id} className="lp-fadeup" style={{ padding: 16, animationDelay: `${i * 0.04}s` }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
              <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
                <div style={{ width: 34, height: 34, borderRadius: 9, background: C.primarySoft, color: C.primary, fontWeight: 700, fontFamily: FONT_DISPLAY, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13 }}>
                  {c.name[0]}
                </div>
                <div>
                  <div style={{ fontWeight: 700, fontSize: 14 }}>{c.name}</div>
                  <div style={{ fontSize: 11.5, color: C.faint }}>{c.location}</div>
                </div>
              </div>
              <ScoreRing score={c.score} size={40} stroke={4} />
            </div>
            <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 10 }}>
              <Badge tone="primary">{c.industry}</Badge>
              <Badge>{c.employees} emp.</Badge>
              {c.hiring && <Badge tone="accent" dot>Hiring</Badge>}
            </div>
            <div style={{ fontSize: 12, color: C.muted, marginBottom: 4 }}>{c.revenue} revenue · {c.funding}</div>
            <div style={{ fontSize: 12, color: C.accentDeep, fontWeight: 600 }}>{c.growth}</div>
          </Card>
        ))}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Analytics                                                           */
/* ------------------------------------------------------------------ */
function Analytics() {
  const [range, setRange] = useState("30d");
  return (
    <div>
      <SectionTitle eyebrow="Analytics" title="Pipeline performance" action={
        <div style={{ display: "flex", gap: 4, background: C.surfaceAlt, padding: 3, borderRadius: 9, border: `1px solid ${C.border}` }}>
          {["7d", "30d", "90d", "Custom"].map((r) => (
            <span key={r} onClick={() => setRange(r)} style={{
              padding: "5px 11px", borderRadius: 7, fontSize: 12.5, fontWeight: 600, cursor: "pointer",
              background: range === r ? C.surface : "transparent", color: range === r ? C.primary : C.muted,
              boxShadow: range === r ? "0 1px 3px rgba(0,0,0,0.08)" : "none",
            }}>{r}</span>
          ))}
        </div>
      } />
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(150px,1fr))", gap: 14, marginBottom: 18 }}>
        <KPI label="Leads discovered" value={2308} delta="+18%" icon={Users} />
        <KPI label="Leads enriched" value={1904} delta="+9%" icon={Database} />
        <KPI label="Verified contacts" value={1580} delta="+6%" icon={ShieldCheck} />
        <KPI label="Conversion rate" value={4.8} format={(v) => v.toFixed(1) + "%"} delta="+0.6pt" icon={TrendingUp} />
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1.5fr 1fr", gap: 16 }}>
        <Card style={{ padding: 18 }}>
          <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 12 }}>Leads by source</div>
          <ResponsiveContainer width="100%" height={230}>
            <BarChart data={[{ s: "AI Research", v: 640 }, { s: "Manual Search", v: 480 }, { s: "CSV Import", v: 210 }, { s: "Enrichment", v: 340 }, { s: "Referral", v: 120 }]}>
              <CartesianGrid vertical={false} stroke={C.border} />
              <XAxis dataKey="s" tick={{ fontSize: 11, fill: C.faint }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: C.faint }} axisLine={false} tickLine={false} width={30} />
              <Tooltip contentStyle={{ borderRadius: 8, border: `1px solid ${C.border}`, fontSize: 12 }} />
              <Bar dataKey="v" radius={[5, 5, 0, 0]} fill={C.accent} />
            </BarChart>
          </ResponsiveContainer>
        </Card>
        <Card style={{ padding: 18 }}>
          <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 12 }}>Campaign performance</div>
          {[
            { name: "UK SaaS Outbound", conv: 6.2 },
            { name: "Enterprise CTO Push", conv: 3.9 },
            { name: "Fintech Expansion", conv: 5.1 },
          ].map((c) => (
            <div key={c.name} style={{ marginBottom: 12 }}>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12.5, marginBottom: 4 }}>
                <span style={{ fontWeight: 600 }}>{c.name}</span>
                <span style={{ fontFamily: FONT_MONO, color: C.accentDeep, fontWeight: 700 }}>{c.conv}%</span>
              </div>
              <div style={{ height: 6, borderRadius: 4, background: C.border }}>
                <div style={{ width: `${c.conv * 10}%`, height: "100%", borderRadius: 4, background: C.primary }} />
              </div>
            </div>
          ))}
        </Card>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Campaigns                                                           */
/* ------------------------------------------------------------------ */
function Campaigns() {
  const rows = [
    { name: "UK SaaS Outbound", list: "UK SaaS Prospects", status: "Running", prospects: 84, replies: 11, meetings: 4 },
    { name: "Enterprise CTO Push", list: "Enterprise CTOs", status: "Paused", prospects: 41, replies: 5, meetings: 1 },
    { name: "Fintech Expansion", list: "High Intent Leads", status: "Draft", prospects: 0, replies: 0, meetings: 0 },
    { name: "Agency Intro Series", list: "Agency Prospects", status: "Completed", prospects: 27, replies: 8, meetings: 3 },
  ];
  const toneFor = { Running: "accent", Paused: "warn", Draft: "neutral", Completed: "primary" };
  return (
    <div>
      <SectionTitle eyebrow="Campaigns" title="Outreach campaigns" action={<Btn icon={Plus} size="sm">New campaign</Btn>} />
      <Card style={{ overflow: "hidden" }} className="lp-table-wrap">
        <table style={{ width: "100%", fontSize: 13 }}>
          <thead>
            <tr style={{ background: C.surfaceAlt, borderBottom: `1px solid ${C.border}` }}>
              {["Campaign", "List", "Status", "Prospects", "Replies", "Meetings", "Conversion"].map((h) => (
                <th key={h} style={{ textAlign: "left", padding: "10px 14px", fontSize: 11.5, color: C.muted, fontWeight: 700, textTransform: "uppercase" }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((r, i) => (
              <tr key={r.name} className="lp-row" style={{ borderBottom: i < rows.length - 1 ? `1px solid ${C.border}` : "none" }}>
                <td style={{ padding: "12px 14px", fontWeight: 600 }}>{r.name}</td>
                <td style={{ padding: "12px 14px", color: C.muted }}>{r.list}</td>
                <td style={{ padding: "12px 14px" }}><Badge tone={toneFor[r.status]} dot={r.status === "Running"}>{r.status}</Badge></td>
                <td style={{ padding: "12px 14px", fontFamily: FONT_MONO }}>{r.prospects}</td>
                <td style={{ padding: "12px 14px", fontFamily: FONT_MONO }}>{r.replies}</td>
                <td style={{ padding: "12px 14px", fontFamily: FONT_MONO }}>{r.meetings}</td>
                <td style={{ padding: "12px 14px", fontFamily: FONT_MONO, color: C.accentDeep, fontWeight: 700 }}>{r.prospects ? ((r.replies / r.prospects) * 100).toFixed(1) : "0.0"}%</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Simple placeholder-style views (Enrichment, Integrations, Settings) */
/* ------------------------------------------------------------------ */
function Enrichment() {
  const cats = [
    { name: "Email", status: "Verified", pct: 92 },
    { name: "Phone", status: "Found", pct: 68 },
    { name: "Job title", status: "Verified", pct: 97 },
    { name: "Technology stack", status: "Found", pct: 74 },
    { name: "Revenue", status: "Needs Verification", pct: 41 },
    { name: "Social profiles", status: "Found", pct: 81 },
  ];
  return (
    <div>
      <SectionTitle eyebrow="Data Enrichment" title="Enrichment coverage across your database" action={<Btn size="sm" icon={Zap}>Run bulk enrichment</Btn>} />
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(220px,1fr))", gap: 14 }}>
        {cats.map((c) => (
          <Card key={c.name} style={{ padding: 16 }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
              <span style={{ fontWeight: 700, fontSize: 13.5 }}>{c.name}</span>
              <Badge tone={c.status === "Verified" ? "accent" : c.status === "Found" ? "primary" : "warn"}>{c.status}</Badge>
            </div>
            <div style={{ height: 6, borderRadius: 4, background: C.border, marginBottom: 6 }}>
              <div style={{ width: `${c.pct}%`, height: "100%", borderRadius: 4, background: c.pct > 70 ? C.accent : C.primary }} />
            </div>
            <div style={{ fontSize: 11.5, color: C.faint }}>{c.pct}% coverage</div>
          </Card>
        ))}
      </div>
    </div>
  );
}

function Integrations() {
  const items = [
    { name: "Gmail", connected: true }, { name: "Outlook", connected: false },
    { name: "Google Sheets", connected: true }, { name: "HubSpot", connected: true },
    { name: "Salesforce", connected: false }, { name: "Slack", connected: true },
    { name: "Zapier", connected: false }, { name: "Webhooks", connected: false },
  ];
  return (
    <div>
      <SectionTitle eyebrow="Integrations" title="Connect LeadPilot to your stack" />
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(220px,1fr))", gap: 14 }}>
        {items.map((it) => (
          <Card key={it.name} style={{ padding: 16, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <div style={{ width: 32, height: 32, borderRadius: 8, background: C.surfaceAlt, border: `1px solid ${C.border}`, display: "flex", alignItems: "center", justifyContent: "center" }}>
                <Globe2 size={15} color={C.muted} />
              </div>
              <span style={{ fontWeight: 600, fontSize: 13.5 }}>{it.name}</span>
            </div>
            <Btn size="sm" variant={it.connected ? "subtle" : "ghost"}>{it.connected ? "Connected" : "Connect"}</Btn>
          </Card>
        ))}
      </div>
    </div>
  );
}

function SettingsView() {
  const items = ["Profile", "Workspace", "Team members", "Roles", "Billing", "Notifications", "Security", "API keys", "Data preferences"];
  return (
    <div>
      <SectionTitle eyebrow="Settings" title="Workspace settings" />
      <Card style={{ padding: 0 }}>
        {items.map((it, i) => (
          <div key={it} className="lp-row" style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "13px 18px", borderBottom: i < items.length - 1 ? `1px solid ${C.border}` : "none", cursor: "pointer" }}>
            <span style={{ fontSize: 13.5, fontWeight: 600 }}>{it}</span>
            <ChevronRight size={15} color={C.faint} />
          </div>
        ))}
      </Card>
    </div>
  );
}

function People({ onOpenPerson }) {
  return (
    <div>
      <SectionTitle eyebrow="People" title={`${PEOPLE.length} contacts in your database`} />
      <Card className="lp-table-wrap lp-scrollbar" style={{ overflow: "hidden" }}>
        <table style={{ width: "100%", fontSize: 13 }}>
          <thead>
            <tr style={{ background: C.surfaceAlt, borderBottom: `1px solid ${C.border}` }}>
              {["Name", "Title", "Department", "Company", "Score", "Verification"].map((h) => (
                <th key={h} style={{ textAlign: "left", padding: "10px 14px", fontSize: 11.5, color: C.muted, fontWeight: 700, textTransform: "uppercase" }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {PEOPLE.map((p, i) => (
              <tr key={p.id} className="lp-row" style={{ borderBottom: i < PEOPLE.length - 1 ? `1px solid ${C.border}` : "none", cursor: "pointer" }} onClick={() => onOpenPerson(p)}>
                <td style={{ padding: "10px 14px", fontWeight: 600, whiteSpace: "nowrap" }}>{p.name}</td>
                <td style={{ padding: "10px 14px", color: C.ink2, whiteSpace: "nowrap" }}>{p.title}</td>
                <td style={{ padding: "10px 14px", color: C.muted, whiteSpace: "nowrap" }}>{p.dept}</td>
                <td style={{ padding: "10px 14px", color: C.ink2, whiteSpace: "nowrap" }}>{p.company}</td>
                <td style={{ padding: "10px 14px", fontFamily: FONT_MONO, fontWeight: 700, color: p.score >= 80 ? C.accentDeep : C.primary }}>{p.score}</td>
                <td style={{ padding: "10px 14px" }}><Badge tone={p.verification === "Verified" ? "accent" : "warn"}>{p.verification}</Badge></td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  App shell                                                           */
/* ------------------------------------------------------------------ */
function AppShell({ onExit }) {
  const [nav, setNav] = useState("overview");
  const [drawerPerson, setDrawerPerson] = useState(null);
  const [collapsed, setCollapsed] = useState(false);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  const view = {
    overview: <Overview onOpenPerson={setDrawerPerson} goFindLeads={() => setNav("find")} />,
    find: <FindLeads onOpenPerson={setDrawerPerson} />,
    companies: <Companies />,
    people: <People onOpenPerson={setDrawerPerson} />,
    lists: <Lists onOpenPerson={setDrawerPerson} />,
    research: <AIResearch />,
    enrichment: <Enrichment />,
    campaigns: <Campaigns />,
    analytics: <Analytics />,
    integrations: <Integrations />,
    settings: <SettingsView />,
  }[nav];

  const navLabel = NAV_ITEMS.find((n) => n.id === nav)?.label;

  return (
    <div className="lp-scope" style={{ display: "flex", height: "100%", background: C.bg }}>
      {/* Sidebar */}
      <div style={{
        width: collapsed ? 68 : 224, flexShrink: 0, background: C.surface, borderRight: `1px solid ${C.border}`,
        display: "flex", flexDirection: "column", transition: "width .2s ease", overflow: "hidden",
      }} className="lp-hide-mobile">
        <div style={{ display: "flex", alignItems: "center", gap: 9, padding: "16px 16px", borderBottom: `1px solid ${C.border}`, cursor: "pointer" }} onClick={onExit}>
          <div style={{ width: 26, height: 26, borderRadius: 7, background: C.primary, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
            <Radar size={14} color="#fff" />
          </div>
          {!collapsed && <span style={{ fontFamily: FONT_DISPLAY, fontWeight: 700, fontSize: 15 }}>LeadPilot</span>}
        </div>
        <div style={{ flex: 1, padding: 10, overflowY: "auto" }} className="lp-scrollbar">
          {NAV_ITEMS.map((it) => (
            <div key={it.id} onClick={() => setNav(it.id)} className="lp-navitem" style={{
              display: "flex", alignItems: "center", gap: 11, padding: "9px 11px", borderRadius: 9, marginBottom: 2,
              background: nav === it.id ? C.primarySoft : "transparent", color: nav === it.id ? C.primary : C.ink2,
            }}>
              <it.icon size={16} strokeWidth={2} style={{ flexShrink: 0 }} />
              {!collapsed && <span style={{ fontSize: 13.5, fontWeight: nav === it.id ? 700 : 500, whiteSpace: "nowrap" }}>{it.label}</span>}
            </div>
          ))}
        </div>
        <div style={{ padding: 10, borderTop: `1px solid ${C.border}` }}>
          <div onClick={() => setCollapsed(!collapsed)} className="lp-navitem" style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 11px", borderRadius: 9, color: C.faint }}>
            {collapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
            {!collapsed && <span style={{ fontSize: 12.5 }}>Collapse</span>}
          </div>
        </div>
      </div>

      {/* Main */}
      <div style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column", height: "100%" }}>
        {/* Topbar */}
        <div style={{ height: 60, flexShrink: 0, borderBottom: `1px solid ${C.border}`, background: C.surface, display: "flex", alignItems: "center", gap: 14, padding: "0 20px", position: "sticky", top: 0, zIndex: 20 }}>
          <Menu size={18} className="lp-hide-mobile" style={{ display: "none" }} />
          <div style={{ display: "flex", alignItems: "center", gap: 8, background: C.surfaceAlt, border: `1px solid ${C.border}`, borderRadius: 9, padding: "7px 11px", flex: 1, maxWidth: 380 }}>
            <Search size={15} color={C.faint} />
            <input placeholder="Search companies, people, lists…" style={{ border: "none", background: "transparent", fontSize: 13, width: "100%", color: C.ink }} />
          </div>
          <div style={{ flex: 1 }} className="lp-hide-mobile" />
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
            <div className="lp-hide-mobile" style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12.5, fontWeight: 600, color: C.ink2, background: C.surfaceAlt, padding: "6px 10px", borderRadius: 8, border: `1px solid ${C.border}` }}>
              <CreditCard size={13} color={C.accent} /> 3,240 credits
            </div>
            <HelpCircle size={17} color={C.faint} className="lp-hide-mobile" />
            <div style={{ position: "relative" }}>
              <Bell size={17} color={C.faint} />
              <span style={{ position: "absolute", top: -3, right: -3, width: 7, height: 7, borderRadius: 999, background: C.danger }} />
            </div>
            <div style={{ width: 30, height: 30, borderRadius: 999, background: C.primary, color: "#fff", fontSize: 12.5, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center" }}>JD</div>
          </div>
        </div>

        {/* Content */}
        <div className="lp-scrollbar" style={{ flex: 1, overflowY: "auto", padding: "22px 24px 60px" }}>
          <div key={nav} className="lp-fadein">{view}</div>
        </div>
      </div>

      <ProspectDrawer person={drawerPerson} onClose={() => setDrawerPerson(null)} />
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Root                                                                */
/* ------------------------------------------------------------------ */
export default function LeadPilotPrototype() {
  const [screen, setScreen] = useState("landing");
  return (
    <div style={{ height: "100vh", width: "100%", overflow: "hidden" }}>
      <GlobalStyle />
      {screen === "landing"
        ? <div style={{ height: "100%", overflowY: "auto" }} className="lp-scrollbar"><Landing onEnter={() => setScreen("app")} /></div>
        : <AppShell onExit={() => setScreen("landing")} />}
    </div>
  );
}
